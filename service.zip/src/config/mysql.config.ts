const devConfig = {
  host: 'localhost',
  database: 'gpt',
  user: 'root',
  password: 'Aitek2022!.',
}

// const prodConfig = {
//   host: 'localhost',
//   database: 'gpt',
//   user: 'root',
//   password: '3349300',
// }
export default devConfig
